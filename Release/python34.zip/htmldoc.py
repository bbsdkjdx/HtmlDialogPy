import ctypes
import time

#com interface can be used in multi-thread.
ctypes.windll.ole32.CoInitializeEx(0,0)

def open_ie(url='',wait_complete=True):
    'return ie com instance.'
    from win32com import client
    ie=client.Dispatch('InternetExplorer.Application')
    ie.Visible=1
    ie.Navigate2(url)
    while wait_complete and ie.BUSY:
    	time.sleep(0.2)
    return ie

def wnd2htmldoc(hwn):
    import win32com.client,pythoncom
    result=ctypes.c_uint32(0)
    msg = ctypes.windll.user32.RegisterWindowMessageW('WM_HTML_GETOBJECT')
    ret= ctypes.windll.user32.SendMessageTimeoutW(hwn, msg, 0, 0, 2, 1000,ctypes.byref(result))
    ob = pythoncom.ObjectFromLresult(result.value, pythoncom.IID_IDispatch, 0)
    doc = win32com.client.dynamic.Dispatch(ob)
    return doc

def trace(rt,path):
    ret=rt
    for x in path:
        if x==-1:
            ret=ret.contentDocument
        else:
            ret=ret.childNodes[x]
    return ret

#search text node:node.NodeValue
def gen_node_path(rt,judger):
    def myjudger(x):
        try:
            if judger(x):
                return True
        except:
            pass
        return False

    from collections import deque
    dq=deque()
    dq.append((rt,[]))
    while dq:
        nd,pth=dq.popleft()
        if nd.NodeName=='IFRAME':
            try:#if frame not load complete,an error will occur.
                nd=nd.contentDocument
            except:
            	continue
            if myjudger(nd):
                yield pth+[-1]
            dq.append((nd,pth+[-1]))
            continue
        try:
            for n,x in enumerate(nd.childNodes):
                if myjudger(x):
                    yield pth+[n]
                dq.append((x,pth+[n]))
        except:
            pass

def _node_info(nd):
	def node_attr(nd,name):
		try:
			atr=nd.__getattr__(name)
			if atr:
				return name+':'+atr
		except:
			pass
		return ''
	attrs=['NodeName','id','classname','title','NodeValue']

	return '  '.join((node_attr(nd,x) for x in attrs))


def manual_path(rt):
	nd=rt
	path=[]
	while 1:
		if nd.NodeName=='IFRAME':
			path.append(-1)
			nd=nd.contentDocument
			continue
		childs=nd.childNodes
		if childs.length==0:
			break
		print('*'*30)
		for n in range(childs.length):
			child=childs[n]
			print(n,_node_info(child))
		sel=input('(b)ack,or (e)nd or number:')
		try:
			if sel=='b':
				nd=nd.parentNode
				path.pop()
				continue
			if sel=='e':
				break
			nsel=int(sel)
			path.append(nsel)
			nd=childs[nsel]
		except:
			pass
	return path
